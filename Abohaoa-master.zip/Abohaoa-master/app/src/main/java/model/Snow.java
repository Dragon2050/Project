package model;

/**
 * Created by Anon on 12/15/2016.
 */

public class Snow {
    private int percipitation;

    public int getPercipitation() {
        return percipitation;
    }

    public void setPercipitation(int percipitation) {
        this.percipitation = percipitation;
    }
}

