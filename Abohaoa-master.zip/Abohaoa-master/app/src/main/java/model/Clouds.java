package model;

/**
 * Created by Anon on 12/15/2016.
 */

public class Clouds {

    private int precipitation;

    public int getPrecipitation(){
        return precipitation;
    }

    public void setPrecipitation(int precipitation){
        this.precipitation=precipitation;
    }
}

